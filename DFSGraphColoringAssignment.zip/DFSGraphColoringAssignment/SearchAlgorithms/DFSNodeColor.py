"""
(c) 2021 James & Anshul
Date: 8/10/2021
Name: James Rozsypal & Anshul Chauhan
Student ID: 015668339 & 016246735
Email: james.rozsypal@student.csulb.edu & anshul.chauhan@student.csulb.edu
"""

class DFSNodeColor(object):
	
    def __init__(self, graph, size, color_names):

        self.graph = graph
        self.size = size
        # the starting node should be the node with the most neighbors
        self.start_node = (self.graph.get_most_connected_node()).get_id()
        # self.start_node = 4
        self.color_names = color_names
        

    def DFS_util(self, s):
        
        s.set_visited(True)
                
        if len(s.get_color_list()) != 0:
            s.set_color(s.get_color_list()[0])
            for v in s.adjacent:
                n = self.graph.get_vertex(v.get_id())
                if n.get_visited() == False and len(n.get_color_list()) > 1:
                    n.update_color_list(s.get_color_list()[0])
        else:
            print("No colors left!")
            exit()
        
        print(s.get_id(), "------>", self.color_names[s.get_color()])
        
        node = self.graph.get_vertex(s.get_id())
        for v in node.adjacent:
            n = self.graph.get_vertex(v.get_id())
            if n.get_visited() == False:
                self.DFS_util(n)


    def DFS_recursive(self):
        s_node = self.graph.get_vertex(self.start_node)
        self.DFS_util(s_node)


# =============================================================================
# END OF DFSNodeColor 
# =============================================================================
