"""
(c) 2021 James & Anshul
Date: 8/10/2021
Name: James Rozsypal & Anshul Chauhan
Student ID: 015668339 & 016246735
Email: james.rozsypal@student.csulb.edu & anshul.chauhan@student.csulb.edu
"""

import pandas as pd
from Data.LoadData import LoadData


class Graph(object):
    """ Constructs a graph data structure. """
    def __init__(self, data_file_path = "", color_list = []):

        ld = LoadData(data_file_path)
        self.data = ld.LoadData_Pandas()
        self.columns_count = ld.ColumnsCount()
        
        self.color_list = color_list
        self.vert_dict = {}
        self.num_vertices = 0


    def __iter__(self):
        return iter(self.vert_dict.values())


    def graph_length(self):
        return 	self.columns_count


    def graph_build(self):
        """ This method construct graph from a data file """

        for row in range(self.columns_count):
            self.add_vertex(row)
            for column in range(self.columns_count):
                if self.data.loc[row,column] != 0:
                    self.add_edge(row, column, self.data.loc[row,column]) 


    def add_vertex(self, node):

        self.num_vertices = self.num_vertices + 1
        new_vertex = Vertex(node, self.color_list)
        self.vert_dict[node] = new_vertex
        return new_vertex


    def get_vertex(self, n):

        if n in self.vert_dict:
            return self.vert_dict[n]
        else:
            return None


    def add_edge(self, frm, to, cost = 0):

        if frm not in self.vert_dict:
            self.add_vertex(frm)
            
        if to not in self.vert_dict:
            self.add_vertex(to)

        self.vert_dict[frm].add_neighbor(self.vert_dict[to], cost)

		# The line below will be enabled if the graph is not directed
        # self.vert_dict[to].add_neighbor(self.vert_dict[frm], cost)


    def get_vertices(self):
        return self.vert_dict.keys()
    
    
    def get_most_connected_node(self):
        """
        This method finds the vertex with the most number of neighbors
        in order to find the correct vertex to start searching from
        """
        largest = 0
        node_temp = None
        
        for node in self.vert_dict.values():
            if node.get_neighbor_count() > largest:
                largest = node.get_neighbor_count()
                node_temp = node
        
        return node_temp


    def graph_summary(self):
		
        print("The number of nodes in the graph is: ", self.columns_count)

        for v in self.vert_dict.values():
            for w in v.get_connections():
                vid = v.get_id()
                wid = w.get_id()
                visited = w.get_visited()
                print ('( %s , %s, %3d, %s)' %( vid, wid, v.get_weight(w), visited))

        for v in self.vert_dict.values():
            print ('g.vert_dict[%s]=%s' %(v.get_id(), self.vert_dict[v.get_id()]))

# =============================================================================
# END OF GRAPH/START OF VERTEX
# =============================================================================
    
class Vertex:
    """ keeps a node information """

    def __init__(self, node, color_list):
        self.id = node
        self.adjacent = {}
        self.visited = False
        self.c_list = color_list.copy()
        self.color = -1
        self.neighbor_count = 0


    def __str__(self):
        return str(self.id) + ' adjacent: ' + str([x.id for x in self.adjacent])

    def add_neighbor(self, neighbor, weight=0):
        self.adjacent[neighbor] = weight
        self.neighbor_count = self.neighbor_count + 1
	
    def get_connections(self):
        return self.adjacent.keys()  

    def get_id(self):
        return self.id

    def set_visited(self, visited):
        self.visited = visited

    def get_visited(self):
        return self.visited

    def get_weight(self, neighbor):
        return self.adjacent[neighbor]
    
    def get_color_list(self):
        return self.c_list
    
    # updates a nodes color list after color assignment
    def update_color_list(self, item):
        self.c_list.remove(item)
    
    def set_color(self, color_id):
        self.color = color_id
        
    def get_color(self):
        return self.color
    
    def get_neighbor_count(self):
        return self.neighbor_count
